# Student Course Registration System
## CENG110 – Programming and Computation II | Project 1

---

## Project Structure

```
project/
├── include/
│   ├── student.h               # Student ADT interface
│   ├── course.h                # Course ADT interface
│   └── registration_manager.h  # RegistrationManager ADT interface
├── src/
│   ├── student.c               # Student ADT implementation
│   ├── course.c                # Course ADT implementation
│   ├── registration_manager.c  # RegistrationManager + linked list
│   └── main.c                  # Entry point, menu, test cases
└── Makefile
```

---

## Compilation

Requires **GCC** (or any C11-compatible compiler) and **Make**.

```bash
# Build the executable
make

# Build and run immediately
make run

# Clean build artifacts
make clean
```

Manual compilation (without Make):

```bash
gcc -Wall -Wextra -pedantic -std=c11 -Iinclude \
    src/student.c src/course.c src/registration_manager.c src/main.c \
    -o registration_system
```

---

## Execution

```bash
./registration_system
```

On startup you will be prompted to select a mode:

```
1. Interactive Menu   — use the system manually via a numbered menu
2. Run Automated Tests — execute all 5 test cases and print results
```

---

## Interactive Menu Options

| # | Action |
|---|--------|
| 1 | Add a student (ID, name, year) |
| 2 | Remove a student by ID |
| 3 | Search a student by ID |
| 4 | List all students |
| 5 | Sort students by ID (ascending) |
| 6 | Sort students by name (alphabetical) |
| 7 | Add a course (ID, name, capacity) |
| 8 | Remove a course by ID |
| 9 | List all courses |
| 10 | Register a student for a course |
| 11 | Drop a student from a course |
| 0 | Exit |

---

## Design Notes

- **ADTs**: All struct definitions are private to their `.c` files. External code interacts only through function interfaces.
- **Data structure**: Singly-linked list. Chosen for O(1) head insertion and no fixed-size limit.
- **Sorting**: Insertion sort on the linked list — O(n²) worst case, appropriate for expected data sizes.
- **Validation**: Duplicate IDs, non-existent records, full course capacity, and already-enrolled cases are all detected and reported via `[ERROR]` messages.

---

## Test Cases (Automated)

| # | Scenario | Coverage |
|---|----------|----------|
| 1 | Add students/courses, register, list | Normal operation |
| 2 | Empty system — search & remove | Edge case |
| 3 | Non-existent IDs, full course | Invalid input |
| 4 | Duplicate student ID, duplicate course ID, double-enrol | Duplicates |
| 5 | Sort by ID then by name | Sorting correctness |
