/* ============================================================
 * FILE:    main.c
 * MODULE:  Entry Point
 *
 * PURPOSE:
 *   Provides two modes of operation:
 *     1. Interactive menu — user controls the system manually.
 *     2. Automated tests — 5 test cases run and print results.
 *
 * USAGE:
 *   Compile with 'make', then run './registration_system'.
 *   Select mode 1 for interactive use, mode 2 for tests.
 * ============================================================ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "registration_manager.h"

/* ---- Forward declarations ---- */
static void run_tests(void);
static void print_separator(const char *title);
static void interactive_menu(RegistrationManager *rm);

/* ============================================================
 * MAIN
 * ============================================================ */
int main(void) {
    printf("========================================\n");
    printf("  Student Course Registration System\n");
    printf("  CENG110 - Programming and Computation II\n");
    printf("========================================\n\n");

    printf("Select mode:\n");
    printf("  1. Interactive Menu\n");
    printf("  2. Run Automated Tests\n");
    printf("Choice: ");

    int choice;
    if (scanf("%d", &choice) != 1) choice = 2;

    if (choice == 1) {
        /* Create a fresh manager, hand it to the menu, destroy on exit */
        RegistrationManager *rm = rm_create();
        interactive_menu(rm);
        rm_destroy(rm);
    } else {
        run_tests();
    }

    return 0;
}

/* ============================================================
 * INTERACTIVE MENU
 * Presents a numbered menu in a loop until the user exits (0).
 * Each option calls the appropriate RegistrationManager function.
 * ============================================================ */
static void interactive_menu(RegistrationManager *rm) {
    int  opt;
    char name[64];
    int  a, b;

    while (1) {
        printf("\n========== MENU ==========\n");
        printf(" 1. Add Student\n");
        printf(" 2. Remove Student\n");
        printf(" 3. Search Student\n");
        printf(" 4. List Students\n");
        printf(" 5. Sort Students by ID\n");
        printf(" 6. Sort Students by Name\n");
        printf(" 7. Add Course\n");
        printf(" 8. Remove Course\n");
        printf(" 9. List Courses\n");
        printf("10. Register Student for Course\n");
        printf("11. Drop Student from Course\n");
        printf(" 0. Exit\n");
        printf("==========================\n");
        printf("Choice: ");

        if (scanf("%d", &opt) != 1) break;

        switch (opt) {

            case 0:  /* Exit */
                printf("Goodbye!\n");
                return;

            case 1:  /* Add Student */
                printf("Student ID: "); scanf("%d",   &a);
                printf("Name: ");       scanf("%63s",  name);
                printf("Year: ");       scanf("%d",   &b);
                if (rm_add_student(rm, a, name, b) == 0)
                    printf("  [OK] Student added.\n");
                break;

            case 2:  /* Remove Student */
                printf("Student ID to remove: "); scanf("%d", &a);
                if (rm_remove_student(rm, a) == 0)
                    printf("  [OK] Student removed.\n");
                break;

            case 3: {  /* Search Student */
                printf("Student ID to search: "); scanf("%d", &a);
                Student *s = rm_search_student(rm, a);
                if (s) student_print(s);
                else   printf("  [ERROR] Student not found.\n");
                break;
            }

            case 4:  /* List all students */
                rm_list_students(rm);
                break;

            case 5:  /* Sort by ID */
                rm_sort_students_by_id(rm);
                printf("  [OK] Sorted by ID.\n");
                rm_list_students(rm);
                break;

            case 6:  /* Sort by name */
                rm_sort_students_by_name(rm);
                printf("  [OK] Sorted by name.\n");
                rm_list_students(rm);
                break;

            case 7:  /* Add Course */
                printf("Course ID: ");    scanf("%d",  &a);
                printf("Course name: "); scanf("%63s", name);
                printf("Capacity: ");    scanf("%d",  &b);
                if (rm_add_course(rm, a, name, b) == 0)
                    printf("  [OK] Course added.\n");
                break;

            case 8:  /* Remove Course */
                printf("Course ID to remove: "); scanf("%d", &a);
                if (rm_remove_course(rm, a) == 0)
                    printf("  [OK] Course removed.\n");
                break;

            case 9:  /* List all courses */
                rm_list_courses(rm);
                break;

            case 10:  /* Register student for course */
                printf("Student ID: "); scanf("%d", &a);
                printf("Course ID: ");  scanf("%d", &b);
                rm_register_student(rm, a, b);
                break;

            case 11:  /* Drop student from course */
                printf("Student ID: "); scanf("%d", &a);
                printf("Course ID: ");  scanf("%d", &b);
                rm_drop_course(rm, a, b);
                break;

            default:
                printf("  Invalid option. Please enter 0-11.\n");
        }
    }
}

/* ============================================================
 * HELPER: prints a visible separator with a test case title
 * ============================================================ */
static void print_separator(const char *title) {
    printf("\n+--------------------------------------------------+\n");
    printf("| %-48s |\n", title);
    printf("+--------------------------------------------------+\n");
}

/* ============================================================
 * AUTOMATED TEST CASES
 *
 * Each test creates its own isolated RegistrationManager,
 * exercises specific functionality, and destroys it at the end.
 * ============================================================ */
static void run_tests(void) {

    /* --------------------------------------------------------
     * TEST CASE 1 — Normal Operation
     * Covers: add students, add courses, register students,
     *         list students, list courses.
     * Expected: all registrations succeed; counters update.
     * -------------------------------------------------------- */
    print_separator("TEST 1: Normal - Add, Register, List");
    {
        RegistrationManager *rm = rm_create();

        /* Add three students */
        rm_add_student(rm, 101, "Alice_Smith", 1);
        rm_add_student(rm, 102, "Bob_Jones",   2);
        rm_add_student(rm, 103, "Carol_White", 1);

        /* Add three courses */
        rm_add_course(rm, 201, "Calculus_I",         30);
        rm_add_course(rm, 202, "Introduction_to_CS", 25);
        rm_add_course(rm, 203, "Physics_I",          20);

        /* Register students — each call should print [OK] */
        rm_register_student(rm, 101, 201);
        rm_register_student(rm, 101, 202);
        rm_register_student(rm, 102, 201);
        rm_register_student(rm, 103, 203);

        /* Verify by listing both collections */
        rm_list_students(rm);
        rm_list_courses(rm);

        rm_destroy(rm);
    }

    /* --------------------------------------------------------
     * TEST CASE 2 — Edge Case: Empty Structure
     * Covers: search on empty list, remove on empty list,
     *         list on empty list.
     * Expected: search returns NULL; remove returns -1 (error);
     *           list prints "(empty)".
     * -------------------------------------------------------- */
    print_separator("TEST 2: Edge - Empty Structure Operations");
    {
        RegistrationManager *rm = rm_create();

        /* Search in empty system — should return NULL */
        printf("  Searching student 999 in empty system:\n");
        Student *s = rm_search_student(rm, 999);
        printf("  Result: %s\n", s ? "FOUND (unexpected)" : "NOT FOUND (correct)");

        /* Remove from empty system — should return -1 */
        printf("  Removing student 999 from empty system:\n");
        int r = rm_remove_student(rm, 999);
        printf("  Result: %s\n", r == 0 ? "REMOVED (unexpected)" : "ERROR (correct)");

        /* List empty system */
        printf("  Listing students:\n");
        rm_list_students(rm);

        rm_destroy(rm);
    }

    /* --------------------------------------------------------
     * TEST CASE 3 — Invalid Input
     * Covers: registering a non-existent student, registering
     *         when course is full, dropping a non-existent course.
     * Expected: all three calls print [ERROR] and return -1.
     * -------------------------------------------------------- */
    print_separator("TEST 3: Invalid Input - Non-existent IDs & Full Course");
    {
        RegistrationManager *rm = rm_create();

        rm_add_student(rm, 101, "Alice_Smith", 1);
        rm_add_course(rm, 201, "Tiny_Course", 1);  /* Capacity = 1 */

        /* Valid registration — fills the only seat */
        printf("  Register student 101 in course 201:\n");
        rm_register_student(rm, 101, 201);

        /* Invalid: student does not exist */
        printf("  Register student 999 (non-existent) in course 201:\n");
        rm_register_student(rm, 999, 201);

        /* Invalid: course is now full */
        printf("  Add student 102 and attempt enrol — course should be full:\n");
        rm_add_student(rm, 102, "Bob_Jones", 2);
        rm_register_student(rm, 102, 201);

        /* Invalid: course 999 does not exist */
        printf("  Drop student 101 from a non-existent course 999:\n");
        rm_drop_course(rm, 101, 999);

        rm_destroy(rm);
    }

    /* --------------------------------------------------------
     * TEST CASE 4 — Duplicate Records
     * Covers: duplicate student ID, duplicate course ID,
     *         enrolling the same student in the same course twice.
     * Expected: all three duplicates are rejected; original
     *           records remain unchanged.
     * -------------------------------------------------------- */
    print_separator("TEST 4: Duplicate Records");
    {
        RegistrationManager *rm = rm_create();

        rm_add_student(rm, 101, "Alice_Smith", 1);

        /* Attempt to add a second student with the same ID */
        printf("  Adding duplicate student ID 101:\n");
        rm_add_student(rm, 101, "Alice_Duplicate", 3);

        rm_add_course(rm, 201, "Calculus_I", 30);

        /* Attempt to add a second course with the same ID */
        printf("  Adding duplicate course ID 201:\n");
        rm_add_course(rm, 201, "Calculus_Duplicate", 10);

        /* Enrol once — should succeed */
        rm_add_course(rm, 202, "Physics_I", 20);
        rm_register_student(rm, 101, 202);

        /* Attempt to enrol the same student in the same course again */
        printf("  Enrolling student 101 in course 202 a second time:\n");
        rm_register_student(rm, 101, 202);

        /* Show that only the original data exists */
        rm_list_students(rm);

        rm_destroy(rm);
    }

    /* --------------------------------------------------------
     * TEST CASE 5 — Sorting
     * Covers: insertion sort by ID (ascending) and by name
     *         (alphabetical order).
     * Expected: IDs increase monotonically after ID sort;
     *           names are in lexicographic order after name sort.
     * -------------------------------------------------------- */
    print_separator("TEST 5: Sorting Students by ID and by Name");
    {
        RegistrationManager *rm = rm_create();

        /* Add 5 students in deliberately scrambled order */
        rm_add_student(rm, 305, "Zara_Ali",    3);
        rm_add_student(rm, 101, "Alice_Brown", 1);
        rm_add_student(rm, 220, "Mike_Chen",   2);
        rm_add_student(rm, 412, "Bob_Davis",   4);
        rm_add_student(rm, 150, "Nina_Evans",  1);

        printf("\n  --- Before sorting ---");
        rm_list_students(rm);

        /* Sort by numeric ID ascending */
        rm_sort_students_by_id(rm);
        printf("\n  --- After sort by ID (ascending) ---");
        rm_list_students(rm);

        /* Sort by name alphabetically */
        rm_sort_students_by_name(rm);
        printf("\n  --- After sort by Name (alphabetical) ---");
        rm_list_students(rm);

        rm_destroy(rm);
    }

    printf("\n========================================\n");
    printf("  All test cases completed.\n");
    printf("========================================\n");
}
