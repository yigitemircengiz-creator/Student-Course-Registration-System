/* ============================================================
 * FILE:    course.c
 * MODULE:  Course ADT — Implementation
 *
 * PURPOSE:
 *   Implements all operations declared in course.h.
 *   The Course struct is private to this file; callers
 *   only see an opaque pointer and interact via functions.
 * ============================================================ */

#include <stdio.h>
#include <stdlib.h>   /* malloc, free */
#include <string.h>   /* strncpy */
#include "course.h"

/* ------------------------------------------------------------
 * Private struct definition
 * Hidden from all other translation units.
 * ------------------------------------------------------------ */
struct Course {
    int  id;                         /* Unique course identifier          */
    char name[MAX_COURSE_NAME_LEN];  /* Course name (null-terminated)     */
    int  capacity;                   /* Maximum number of students        */
    int  enrollment;                 /* Current number of enrolled students */
};

/* ============================================================
 * CONSTRUCTOR
 * ============================================================ */

/*
 * course_create
 * -------------
 * Allocates and initialises a new Course on the heap.
 *
 * Parameters:
 *   id       - unique numeric course ID
 *   name     - course name (copied into the struct)
 *   capacity - maximum allowed enrolment (1 .. MAX_CAPACITY)
 *
 * Returns:
 *   Pointer to the new Course, or NULL on invalid capacity
 *   or allocation failure.
 */
Course *course_create(int id, const char *name, int capacity) {
    /* Validate capacity range before allocating */
    if (capacity <= 0 || capacity > MAX_CAPACITY) return NULL;

    Course *c = (Course *)malloc(sizeof(Course));
    if (!c) return NULL;

    c->id         = id;
    c->capacity   = capacity;
    c->enrollment = 0;  /* No students enrolled at creation */

    /* Safe string copy with guaranteed null-termination */
    strncpy(c->name, name, MAX_COURSE_NAME_LEN - 1);
    c->name[MAX_COURSE_NAME_LEN - 1] = '\0';

    return c;
}

/* ============================================================
 * DESTRUCTOR
 * ============================================================ */

/*
 * course_destroy
 * --------------
 * Frees all memory associated with a Course.
 * Safe to call with NULL.
 */
void course_destroy(Course *c) {
    if (c) free(c);
}

/* ============================================================
 * GETTERS
 * ============================================================ */

/* Returns the course's unique ID. */
int course_get_id(const Course *c) { return c->id; }

/* Returns a read-only pointer to the course name string. */
const char *course_get_name(const Course *c) { return c->name; }

/* Returns the maximum allowed enrolment. */
int course_get_capacity(const Course *c) { return c->capacity; }

/* Returns the current number of enrolled students. */
int course_get_enrollment(const Course *c) { return c->enrollment; }

/*
 * course_is_full
 * --------------
 * Returns 1 if enrollment has reached capacity, 0 otherwise.
 * Used as a guard before adding a new student to the course.
 */
int course_is_full(const Course *c) { return c->enrollment >= c->capacity; }

/* ============================================================
 * MUTATORS
 * ============================================================ */

/*
 * course_add_enrollment
 * ----------------------
 * Increments the enrollment counter by 1.
 * Must only be called after verifying the course is not full
 * (use course_is_full() first).
 *
 * Returns:  0 on success
 *          -1 if the course is already at full capacity
 */
int course_add_enrollment(Course *c) {
    if (course_is_full(c)) return -1;
    c->enrollment++;
    return 0;
}

/*
 * course_drop_enrollment
 * -----------------------
 * Decrements the enrollment counter by 1.
 * Called when a student drops this course.
 *
 * Returns:  0 on success
 *          -1 if enrollment is already 0 (safety guard)
 */
int course_drop_enrollment(Course *c) {
    if (c->enrollment <= 0) return -1;
    c->enrollment--;
    return 0;
}

/* ============================================================
 * DISPLAY
 * ============================================================ */

/*
 * course_print
 * ------------
 * Prints a formatted one-line summary of the course,
 * showing current enrollment and capacity.
 */
void course_print(const Course *c) {
    printf("  Course  [ID: %d | Name: %-25s | Enrolled: %d/%d]\n",
           c->id, c->name, c->enrollment, c->capacity);
}
