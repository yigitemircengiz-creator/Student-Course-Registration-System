/* ============================================================
 * FILE:    registration_manager.c
 * MODULE:  RegistrationManager ADT — Implementation
 *
 * PURPOSE:
 *   Central coordinator for the registration system.
 *   Manages two singly-linked lists:
 *     - students list  (StudentNode chain)
 *     - courses  list  (CourseNode  chain)
 *
 * DATA STRUCTURE — Singly-Linked List
 *   Chosen over a static array because:
 *     1. O(1) insertion at head — the most frequent operation.
 *     2. No fixed upper bound on the number of students/courses.
 *     3. O(1) deletion once the predecessor node is known.
 *   The trade-off is O(n) search, which is acceptable for the
 *   expected data sizes of a university registration system.
 *
 * ENCAPSULATION:
 *   StudentNode, CourseNode, and the RegistrationManager struct
 *   are all defined here and are invisible to external modules.
 * ============================================================ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "registration_manager.h"

/* ============================================================
 * Private node and manager struct definitions
 * ============================================================ */

/*
 * StudentNode — one element in the students linked list.
 * 'data' owns the Student object; 'next' links to the next node.
 */
typedef struct StudentNode {
    Student            *data;
    struct StudentNode *next;
} StudentNode;

/*
 * CourseNode — one element in the courses linked list.
 */
typedef struct CourseNode {
    Course            *data;
    struct CourseNode *next;
} CourseNode;

/*
 * RegistrationManager — the root object of the system.
 * Holds the heads of both linked lists and their sizes.
 */
struct RegistrationManager {
    StudentNode *students_head;  /* Head of the students linked list */
    CourseNode  *courses_head;   /* Head of the courses  linked list */
    int          student_count;  /* Total number of students         */
    int          course_count;   /* Total number of courses          */
};

/* ============================================================
 * CONSTRUCTOR / DESTRUCTOR
 * ============================================================ */

/*
 * rm_create
 * ---------
 * Allocates and returns an empty RegistrationManager.
 * Both lists start as empty (NULL head, count = 0).
 *
 * Returns NULL on allocation failure.
 */
RegistrationManager *rm_create(void) {
    RegistrationManager *rm = (RegistrationManager *)malloc(sizeof(RegistrationManager));
    if (!rm) return NULL;

    rm->students_head = NULL;
    rm->courses_head  = NULL;
    rm->student_count = 0;
    rm->course_count  = 0;
    return rm;
}

/*
 * rm_destroy
 * ----------
 * Frees all nodes in both linked lists, destroys all Student
 * and Course objects, then frees the manager itself.
 * After this call the pointer is invalid — do not use it.
 */
void rm_destroy(RegistrationManager *rm) {
    if (!rm) return;

    /* Walk the students list and free each node and its data */
    StudentNode *sn = rm->students_head;
    while (sn) {
        StudentNode *tmp = sn->next;
        student_destroy(sn->data);  /* Free the Student object */
        free(sn);                   /* Free the list node      */
        sn = tmp;
    }

    /* Walk the courses list and free each node and its data */
    CourseNode *cn = rm->courses_head;
    while (cn) {
        CourseNode *tmp = cn->next;
        course_destroy(cn->data);
        free(cn);
        cn = tmp;
    }

    free(rm);  /* Free the manager itself */
}

/* ============================================================
 * STUDENT OPERATIONS
 * ============================================================ */

/*
 * rm_add_student
 * --------------
 * Creates a new Student and inserts it at the head of the
 * students linked list.
 *
 * Duplicate check: O(n) — the entire list is scanned first to
 * ensure no student with the same ID already exists.
 * Actual insertion: O(1) — head insertion.
 * Overall complexity: O(n)
 *
 * Returns:  0 on success
 *          -1 if ID is duplicate or allocation fails
 */
int rm_add_student(RegistrationManager *rm, int id, const char *name, int year) {
    /* Scan for duplicate before allocating anything */
    if (rm_search_student(rm, id) != NULL) {
        fprintf(stderr, "  [ERROR] Student with ID %d already exists.\n", id);
        return -1;
    }

    /* Create the Student object */
    Student *s = student_create(id, name, year);
    if (!s) return -1;

    /* Allocate a new list node */
    StudentNode *node = (StudentNode *)malloc(sizeof(StudentNode));
    if (!node) { student_destroy(s); return -1; }

    /* Head insertion: new node points to old head, becomes new head */
    node->data        = s;
    node->next        = rm->students_head;
    rm->students_head = node;
    rm->student_count++;
    return 0;
}

/*
 * rm_remove_student
 * -----------------
 * Searches for a student by ID, then unlinks and frees the node.
 *
 * Uses a two-pointer (prev, curr) traversal so the predecessor
 * can be updated in O(1) once the target is found.
 *
 * Time complexity: O(n) — linear search
 *
 * Returns:  0 on success
 *          -1 if student not found
 */
int rm_remove_student(RegistrationManager *rm, int id) {
    StudentNode *prev = NULL;
    StudentNode *curr = rm->students_head;

    while (curr) {
        if (student_get_id(curr->data) == id) {
            /* Bypass the node: link prev directly to curr->next */
            if (prev) prev->next = curr->next;
            else       rm->students_head = curr->next;  /* Removing head */

            student_destroy(curr->data);
            free(curr);
            rm->student_count--;
            return 0;
        }
        prev = curr;
        curr = curr->next;
    }

    fprintf(stderr, "  [ERROR] Student ID %d not found.\n", id);
    return -1;
}

/*
 * rm_search_student
 * -----------------
 * Linear scan from head to tail comparing each student's ID.
 *
 * Time complexity: O(n) worst case, O(1) best case (head match)
 *
 * Returns: pointer to Student if found, NULL otherwise
 */
Student *rm_search_student(RegistrationManager *rm, int id) {
    StudentNode *curr = rm->students_head;
    while (curr) {
        if (student_get_id(curr->data) == id) return curr->data;
        curr = curr->next;
    }
    return NULL;  /* Not found */
}

/*
 * rm_list_students
 * ----------------
 * Iterates over the students list and calls student_print()
 * for each entry. Prints a header with the current count.
 */
void rm_list_students(const RegistrationManager *rm) {
    printf("\n--- Student List (%d students) ---\n", rm->student_count);
    if (!rm->students_head) { printf("  (empty)\n"); return; }
    StudentNode *curr = rm->students_head;
    while (curr) {
        student_print(curr->data);
        curr = curr->next;
    }
}

/*
 * rm_sort_students_by_id
 * -----------------------
 * Sorts the students linked list in ascending order of student ID
 * using insertion sort directly on the linked list nodes.
 *
 * Algorithm:
 *   Repeatedly remove the head from the unsorted list and insert
 *   it into the correct position in the growing sorted list.
 *
 * Time complexity: O(n^2) — n iterations, each scanning up to n nodes.
 * Space complexity: O(1) — no auxiliary array; only pointers are moved.
 *
 * Acceptable for this application because the number of students
 * in a university registration system is small (typically < 1000).
 */
void rm_sort_students_by_id(RegistrationManager *rm) {
    if (!rm->students_head || !rm->students_head->next) return;  /* 0 or 1 element */

    StudentNode *sorted = NULL;  /* Sorted sub-list (built incrementally) */
    StudentNode *curr   = rm->students_head;

    while (curr) {
        StudentNode *next = curr->next;  /* Save next before relinking */

        if (!sorted || student_get_id(curr->data) <= student_get_id(sorted->data)) {
            /* curr belongs at the front of the sorted list */
            curr->next = sorted;
            sorted     = curr;
        } else {
            /* Find the last node in sorted whose ID < curr's ID */
            StudentNode *tmp = sorted;
            while (tmp->next &&
                   student_get_id(tmp->next->data) < student_get_id(curr->data))
                tmp = tmp->next;

            /* Insert curr after tmp */
            curr->next = tmp->next;
            tmp->next  = curr;
        }
        curr = next;
    }

    rm->students_head = sorted;  /* Update list head to sorted result */
}

/*
 * rm_sort_students_by_name
 * -------------------------
 * Same insertion sort algorithm as rm_sort_students_by_id,
 * but uses strcmp() to compare student names alphabetically.
 *
 * Time complexity: O(n^2)
 */
void rm_sort_students_by_name(RegistrationManager *rm) {
    if (!rm->students_head || !rm->students_head->next) return;

    StudentNode *sorted = NULL;
    StudentNode *curr   = rm->students_head;

    while (curr) {
        StudentNode *next = curr->next;

        if (!sorted ||
            strcmp(student_get_name(curr->data), student_get_name(sorted->data)) <= 0) {
            curr->next = sorted;
            sorted     = curr;
        } else {
            StudentNode *tmp = sorted;
            while (tmp->next &&
                   strcmp(student_get_name(tmp->next->data),
                          student_get_name(curr->data)) < 0)
                tmp = tmp->next;
            curr->next = tmp->next;
            tmp->next  = curr;
        }
        curr = next;
    }

    rm->students_head = sorted;
}

/* ============================================================
 * COURSE OPERATIONS
 * ============================================================ */

/*
 * rm_add_course
 * -------------
 * Creates a new Course and inserts it at the head of the
 * courses linked list after checking for duplicate IDs.
 *
 * Time complexity: O(n) due to duplicate check
 *
 * Returns:  0 on success
 *          -1 if duplicate ID or allocation fails
 */
int rm_add_course(RegistrationManager *rm, int id, const char *name, int capacity) {
    if (rm_search_course(rm, id) != NULL) {
        fprintf(stderr, "  [ERROR] Course with ID %d already exists.\n", id);
        return -1;
    }

    Course *c = course_create(id, name, capacity);
    if (!c) return -1;

    CourseNode *node = (CourseNode *)malloc(sizeof(CourseNode));
    if (!node) { course_destroy(c); return -1; }

    /* Head insertion */
    node->data       = c;
    node->next       = rm->courses_head;
    rm->courses_head = node;
    rm->course_count++;
    return 0;
}

/*
 * rm_remove_course
 * ----------------
 * Finds a course by ID and removes its node from the list.
 *
 * Time complexity: O(n)
 *
 * Returns:  0 on success
 *          -1 if not found
 */
int rm_remove_course(RegistrationManager *rm, int id) {
    CourseNode *prev = NULL;
    CourseNode *curr = rm->courses_head;

    while (curr) {
        if (course_get_id(curr->data) == id) {
            if (prev) prev->next = curr->next;
            else       rm->courses_head = curr->next;

            course_destroy(curr->data);
            free(curr);
            rm->course_count--;
            return 0;
        }
        prev = curr;
        curr = curr->next;
    }

    fprintf(stderr, "  [ERROR] Course ID %d not found.\n", id);
    return -1;
}

/*
 * rm_search_course
 * ----------------
 * Linear scan for a course by ID.
 *
 * Time complexity: O(n)
 *
 * Returns: pointer to Course if found, NULL otherwise
 */
Course *rm_search_course(RegistrationManager *rm, int id) {
    CourseNode *curr = rm->courses_head;
    while (curr) {
        if (course_get_id(curr->data) == id) return curr->data;
        curr = curr->next;
    }
    return NULL;
}

/*
 * rm_list_courses
 * ---------------
 * Iterates over the courses list and prints each one.
 */
void rm_list_courses(const RegistrationManager *rm) {
    printf("\n--- Course List (%d courses) ---\n", rm->course_count);
    if (!rm->courses_head) { printf("  (empty)\n"); return; }
    CourseNode *curr = rm->courses_head;
    while (curr) {
        course_print(curr->data);
        curr = curr->next;
    }
}

/* ============================================================
 * REGISTRATION OPERATIONS
 * ============================================================ */

/*
 * rm_register_student
 * --------------------
 * Enrolls a student in a course, applying all necessary checks:
 *   1. Student must exist.
 *   2. Course must exist.
 *   3. Student must not already be enrolled in the course.
 *   4. Course must not be at full capacity.
 *
 * On success, both sides are updated:
 *   - Student's enrolled_courses[] gains the course ID.
 *   - Course's enrollment counter increments.
 *
 * Time complexity: O(n) — two searches + O(1) updates
 *
 * Returns:  0 on success
 *          -1 on any validation failure
 */
int rm_register_student(RegistrationManager *rm, int student_id, int course_id) {
    /* Look up the student */
    Student *s = rm_search_student(rm, student_id);
    if (!s) {
        fprintf(stderr, "  [ERROR] Student ID %d not found.\n", student_id);
        return -1;
    }

    /* Look up the course */
    Course *c = rm_search_course(rm, course_id);
    if (!c) {
        fprintf(stderr, "  [ERROR] Course ID %d not found.\n", course_id);
        return -1;
    }

    /* Guard: duplicate enrolment */
    if (student_is_enrolled(s, course_id)) {
        fprintf(stderr, "  [ERROR] Student %d is already enrolled in course %d.\n",
                student_id, course_id);
        return -1;
    }

    /* Guard: course capacity */
    if (course_is_full(c)) {
        fprintf(stderr, "  [ERROR] Course %d is full (capacity: %d).\n",
                course_id, course_get_capacity(c));
        return -1;
    }

    /* All checks passed — update both objects */
    student_add_course(s, course_id);    /* Add to student's list */
    course_add_enrollment(c);           /* Increment course counter */

    printf("  [OK] Student %-20s registered for course \"%s\".\n",
           student_get_name(s), course_get_name(c));
    return 0;
}

/*
 * rm_drop_course
 * --------------
 * Removes a student's enrolment from a course.
 *
 * Checks performed:
 *   1. Student must exist.
 *   2. Course must exist.
 *   3. Student must currently be enrolled in the course.
 *
 * On success, both sides are updated:
 *   - Course ID is removed from student's enrolled_courses[].
 *   - Course's enrollment counter decrements.
 *
 * Time complexity: O(n) — two searches + O(k) drop (k <= MAX_COURSES)
 *
 * Returns:  0 on success
 *          -1 on any validation failure
 */
int rm_drop_course(RegistrationManager *rm, int student_id, int course_id) {
    Student *s = rm_search_student(rm, student_id);
    if (!s) {
        fprintf(stderr, "  [ERROR] Student ID %d not found.\n", student_id);
        return -1;
    }

    Course *c = rm_search_course(rm, course_id);
    if (!c) {
        fprintf(stderr, "  [ERROR] Course ID %d not found.\n", course_id);
        return -1;
    }

    /* Guard: student must actually be enrolled */
    if (!student_is_enrolled(s, course_id)) {
        fprintf(stderr, "  [ERROR] Student %d is not enrolled in course %d.\n",
                student_id, course_id);
        return -1;
    }

    /* All checks passed — update both objects */
    student_drop_course(s, course_id);   /* Remove from student's list */
    course_drop_enrollment(c);           /* Decrement course counter   */

    printf("  [OK] Student %-20s dropped course \"%s\".\n",
           student_get_name(s), course_get_name(c));
    return 0;
}

/* ============================================================
 * UTILITY
 * ============================================================ */

/* Returns total number of students currently in the system. */
int rm_student_count(const RegistrationManager *rm) { return rm->student_count; }

/* Returns total number of courses currently in the system. */
int rm_course_count(const RegistrationManager *rm)  { return rm->course_count;  }
