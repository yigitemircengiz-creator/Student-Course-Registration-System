/* ============================================================
 * FILE:    student.c
 * MODULE:  Student ADT — Implementation
 *
 * PURPOSE:
 *   Implements all operations declared in student.h.
 *   The 'Student' struct is defined HERE and nowhere else,
 *   enforcing encapsulation: external modules can only hold
 *   a pointer (Student *) and must call these functions to
 *   read or modify any field.
 *
 * ENCAPSULATION NOTE:
 *   student.h contains only:  typedef struct Student Student;
 *   The actual struct members (id, name, year, ...) are invisible
 *   to any file that #includes student.h. This is the standard
 *   C technique for opaque data types.
 * ============================================================ */

#include <stdio.h>
#include <stdlib.h>   /* malloc, free */
#include <string.h>   /* strncpy, memset */
#include "student.h"

/* ------------------------------------------------------------
 * Private struct definition
 * Only visible inside this translation unit (student.c).
 * ------------------------------------------------------------ */
struct Student {
    int  id;                            /* Unique student identifier      */
    char name[MAX_NAME_LEN];            /* Full name (null-terminated)    */
    int  year;                          /* Academic year (1, 2, 3, ...)   */
    int  enrolled_courses[MAX_COURSES]; /* Array of enrolled course IDs   */
    int  course_count;                  /* Number of currently enrolled   */
};

/* ============================================================
 * CONSTRUCTOR
 * ============================================================ */

/*
 * student_create
 * --------------
 * Allocates and initialises a new Student on the heap.
 *
 * Parameters:
 *   id   - unique numeric student ID
 *   name - student full name (will be copied, not referenced)
 *   year - academic year
 *
 * Returns:
 *   Pointer to the new Student, or NULL if malloc fails.
 *
 * Caller responsibility:
 *   The returned pointer must eventually be passed to
 *   student_destroy() to avoid a memory leak.
 */
Student *student_create(int id, const char *name, int year) {
    Student *s = (Student *)malloc(sizeof(Student));
    if (!s) return NULL;  /* Allocation failed */

    s->id           = id;
    s->year         = year;
    s->course_count = 0;  /* No courses enrolled at creation */

    /* Safe string copy — always null-terminate even if name is too long */
    strncpy(s->name, name, MAX_NAME_LEN - 1);
    s->name[MAX_NAME_LEN - 1] = '\0';

    /* Zero out the course ID array for a clean initial state */
    memset(s->enrolled_courses, 0, sizeof(s->enrolled_courses));

    return s;
}

/* ============================================================
 * DESTRUCTOR
 * ============================================================ */

/*
 * student_destroy
 * ---------------
 * Frees all memory associated with a Student.
 * Safe to call with NULL (no-op).
 */
void student_destroy(Student *s) {
    if (s) free(s);
}

/* ============================================================
 * GETTERS  (read-only access to private fields)
 * ============================================================ */

/* Returns the student's unique numeric ID. */
int student_get_id(const Student *s) { return s->id; }

/* Returns a read-only pointer to the student's name string. */
const char *student_get_name(const Student *s) { return s->name; }

/* Returns the student's academic year. */
int student_get_year(const Student *s) { return s->year; }

/* Returns how many courses the student is currently enrolled in. */
int student_get_course_count(const Student *s) { return s->course_count; }

/*
 * student_get_course_id
 * ----------------------
 * Returns the course ID at position 'index' in the enrolment array.
 * Returns -1 if the index is out of range.
 */
int student_get_course_id(const Student *s, int index) {
    if (index < 0 || index >= s->course_count) return -1;
    return s->enrolled_courses[index];
}

/* ============================================================
 * MUTATORS  (controlled modification of private fields)
 * ============================================================ */

/*
 * student_add_course
 * ------------------
 * Enrolls the student in the given course.
 *
 * Checks performed before adding:
 *   1. The student has not reached the maximum course limit.
 *   2. The student is not already enrolled (no duplicates).
 *
 * Returns:  0 on success
 *          -1 if already enrolled or course array is full
 */
int student_add_course(Student *s, int course_id) {
    /* Guard: maximum enrolment reached */
    if (s->course_count >= MAX_COURSES) return -1;

    /* Guard: duplicate enrolment - same course cannot be added twice */
    if (student_is_enrolled(s, course_id)) return -1;

    /* Append the course ID and increment the counter */
    s->enrolled_courses[s->course_count++] = course_id;
    return 0;
}

/*
 * student_drop_course
 * --------------------
 * Removes a course from the student's enrolment list.
 *
 * After removal, the array is compacted by shifting all
 * subsequent entries one position to the left, so there
 * are never any gaps in enrolled_courses[0..course_count-1].
 *
 * Returns:  0 on success
 *          -1 if the student was not enrolled in the course
 */
int student_drop_course(Student *s, int course_id) {
    for (int i = 0; i < s->course_count; i++) {
        if (s->enrolled_courses[i] == course_id) {

            /* Shift elements left to fill the gap left by removal */
            for (int j = i; j < s->course_count - 1; j++)
                s->enrolled_courses[j] = s->enrolled_courses[j + 1];

            s->course_count--;  /* One fewer course enrolled */
            return 0;
        }
    }
    return -1;  /* Course not found in enrolment list */
}

/*
 * student_is_enrolled
 * --------------------
 * Linear search through enrolled_courses[].
 *
 * Returns: 1 if the student is enrolled in course_id
 *          0 otherwise
 *
 * Time complexity: O(k) where k = course_count (bounded by MAX_COURSES)
 */
int student_is_enrolled(const Student *s, int course_id) {
    for (int i = 0; i < s->course_count; i++)
        if (s->enrolled_courses[i] == course_id) return 1;
    return 0;
}

/* ============================================================
 * DISPLAY
 * ============================================================ */

/*
 * student_print
 * -------------
 * Prints a formatted one-line summary of the student,
 * followed by their enrolled course IDs if any exist.
 */
void student_print(const Student *s) {
    printf("  Student [ID: %d | Name: %-20s | Year: %d | Courses: %d]\n",
           s->id, s->name, s->year, s->course_count);

    /* Print enrolled course IDs on a second line, if any */
    if (s->course_count > 0) {
        printf("    Enrolled in course IDs: ");
        for (int i = 0; i < s->course_count; i++)
            printf("%d%s", s->enrolled_courses[i],
                   i < s->course_count - 1 ? ", " : "\n");
    }
}
