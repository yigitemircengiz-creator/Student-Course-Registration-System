#ifndef REGISTRATION_MANAGER_H
#define REGISTRATION_MANAGER_H

/* ============================================================
 * FILE:    registration_manager.h
 * MODULE:  RegistrationManager ADT — Public Interface
 *
 * PURPOSE:
 *   Declares the RegistrationManager, the top-level coordinator
 *   of the Student Course Registration System. It owns:
 *     - A singly-linked list of Student objects
 *     - A singly-linked list of Course objects
 *
 * DATA STRUCTURE — Singly-Linked List
 *   Both collections use singly-linked lists with head insertion.
 *   Rationale:
 *     - O(1) insertion at head (most frequent operation).
 *     - No fixed-size upper bound (unlike a static array).
 *     - O(n) search and deletion are acceptable for bounded
 *       academic datasets (typically < 1000 students/courses).
 *
 * ENCAPSULATION:
 *   The internal node types (StudentNode, CourseNode) and the
 *   RegistrationManager struct are all private to
 *   registration_manager.c. Callers only see this header.
 * ============================================================ */

#include "student.h"
#include "course.h"

/*
 * Opaque type — struct definition is private to registration_manager.c
 */
typedef struct RegistrationManager RegistrationManager;

/* ---- Constructor / Destructor ---- */

/*
 * rm_create  — allocates an empty RegistrationManager.
 * Returns NULL on allocation failure.
 * Must be freed with rm_destroy() when no longer needed.
 */
RegistrationManager *rm_create(void);

/*
 * rm_destroy — frees all students, courses, list nodes,
 *              and the manager itself. Do not use the pointer
 *              after this call.
 */
void rm_destroy(RegistrationManager *rm);

/* ---- Student operations ---- */

/*
 * rm_add_student — creates a Student and inserts it into the list.
 * Rejects duplicate IDs.
 * Returns 0 on success, -1 on failure.
 * Time: O(n)
 */
int rm_add_student(RegistrationManager *rm, int id, const char *name, int year);

/*
 * rm_remove_student — finds and removes the student with the given ID.
 * Returns 0 on success, -1 if not found.
 * Time: O(n)
 */
int rm_remove_student(RegistrationManager *rm, int id);

/*
 * rm_search_student — returns a pointer to the Student with the given ID,
 * or NULL if not found.
 * Time: O(n)
 */
Student *rm_search_student(RegistrationManager *rm, int id);

/* rm_list_students — prints all students to stdout. */
void rm_list_students(const RegistrationManager *rm);

/*
 * rm_sort_students_by_id   — insertion sort, ascending numeric ID.
 * rm_sort_students_by_name — insertion sort, alphabetical by name.
 * Both operate in-place on the linked list. Time: O(n^2).
 */
void rm_sort_students_by_id(RegistrationManager *rm);
void rm_sort_students_by_name(RegistrationManager *rm);

/* ---- Course operations ---- */

/*
 * rm_add_course — creates a Course and inserts it into the list.
 * Rejects duplicate IDs.
 * Returns 0 on success, -1 on failure.
 */
int rm_add_course(RegistrationManager *rm, int id, const char *name, int capacity);

/*
 * rm_remove_course — finds and removes the course with the given ID.
 * Returns 0 on success, -1 if not found.
 */
int rm_remove_course(RegistrationManager *rm, int id);

/*
 * rm_search_course — returns a pointer to the Course with the given ID,
 * or NULL if not found.
 */
Course *rm_search_course(RegistrationManager *rm, int id);

/* rm_list_courses — prints all courses to stdout. */
void rm_list_courses(const RegistrationManager *rm);

/* ---- Registration operations ---- */

/*
 * rm_register_student — enrolls a student in a course.
 * Validates: student exists, course exists, not already enrolled,
 *            course not full.
 * Updates both the Student object and the Course object on success.
 * Returns 0 on success, -1 on any validation failure.
 */
int rm_register_student(RegistrationManager *rm, int student_id, int course_id);

/*
 * rm_drop_course — removes a student's enrolment from a course.
 * Validates: student exists, course exists, student is enrolled.
 * Updates both objects on success.
 * Returns 0 on success, -1 on any validation failure.
 */
int rm_drop_course(RegistrationManager *rm, int student_id, int course_id);

/* ---- Utility ---- */
int rm_student_count(const RegistrationManager *rm);
int rm_course_count(const RegistrationManager *rm);

#endif /* REGISTRATION_MANAGER_H */
