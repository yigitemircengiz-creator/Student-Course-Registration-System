#ifndef COURSE_H
#define COURSE_H

/* ============================================================
 * FILE:    course.h
 * MODULE:  Course ADT — Public Interface
 *
 * PURPOSE:
 *   Declares the Course Abstract Data Type.
 *   Internal struct members are private to course.c.
 *   All access goes through the functions declared here.
 * ============================================================ */

/* Maximum length of a course name (including null terminator) */
#define MAX_COURSE_NAME_LEN  64

/* Maximum allowed capacity value when creating a course */
#define MAX_CAPACITY         100

/*
 * Opaque type — the struct definition lives in course.c only.
 */
typedef struct Course Course;

/* ---- Constructor / Destructor ---- */

/*
 * course_create — allocates a new Course on the heap.
 *   id       : unique numeric identifier
 *   name     : course name (copied internally)
 *   capacity : maximum number of students (1 .. MAX_CAPACITY)
 * Returns NULL if capacity is out of range or allocation fails.
 */
Course *course_create(int id, const char *name, int capacity);

/*
 * course_destroy — frees all memory owned by the Course.
 * Safe to call with NULL.
 */
void course_destroy(Course *c);

/* ---- Getters ---- */
int         course_get_id(const Course *c);
const char *course_get_name(const Course *c);
int         course_get_capacity(const Course *c);    /* Maximum seats     */
int         course_get_enrollment(const Course *c);  /* Currently filled  */

/*
 * course_is_full — returns 1 if enrollment == capacity, 0 otherwise.
 * Use this before calling course_add_enrollment().
 */
int course_is_full(const Course *c);

/* ---- Mutators ---- */

/*
 * course_add_enrollment — increments the enrollment counter.
 * Returns  0 on success.
 * Returns -1 if the course is already at full capacity.
 */
int course_add_enrollment(Course *c);

/*
 * course_drop_enrollment — decrements the enrollment counter.
 * Returns  0 on success.
 * Returns -1 if enrollment is already 0.
 */
int course_drop_enrollment(Course *c);

/* ---- Display ---- */

/* course_print — prints a formatted summary to stdout. */
void course_print(const Course *c);

#endif /* COURSE_H */
