#ifndef STUDENT_H
#define STUDENT_H

/* ============================================================
 * FILE:    student.h
 * MODULE:  Student ADT — Public Interface
 *
 * PURPOSE:
 *   Declares the Student Abstract Data Type.
 *   The internal struct definition is intentionally hidden
 *   in student.c (opaque pointer pattern). External code may
 *   only interact with Student objects through the functions
 *   listed below — never by accessing struct members directly.
 *
 * USAGE:
 *   #include "student.h"
 *   Student *s = student_create(101, "Alice", 1);
 *   student_print(s);
 *   student_destroy(s);
 * ============================================================ */

/* Maximum length of a student name (including null terminator) */
#define MAX_NAME_LEN   64

/* Maximum number of courses a single student can be enrolled in */
#define MAX_COURSES    10

/*
 * Opaque type declaration.
 * Callers hold a pointer to Student but cannot see its fields.
 * This enforces encapsulation at the language level.
 */
typedef struct Student Student;

/* ---- Constructor / Destructor ---- */

/*
 * student_create  — allocates a new Student on the heap.
 *   id   : unique numeric identifier
 *   name : name string (copied internally)
 *   year : academic year (1, 2, 3, ...)
 * Returns NULL on allocation failure.
 * The caller must call student_destroy() when done.
 */
Student *student_create(int id, const char *name, int year);

/*
 * student_destroy — frees all memory owned by the Student.
 * Safe to call with NULL.
 */
void student_destroy(Student *s);

/* ---- Getters (read-only access) ---- */
int         student_get_id(const Student *s);
const char *student_get_name(const Student *s);
int         student_get_year(const Student *s);
int         student_get_course_count(const Student *s);
int         student_get_course_id(const Student *s, int index);  /* -1 if out of range */

/* ---- Mutators ---- */

/*
 * student_add_course — adds course_id to the enrolment list.
 * Returns  0 on success.
 * Returns -1 if already enrolled or if MAX_COURSES is reached.
 */
int student_add_course(Student *s, int course_id);

/*
 * student_drop_course — removes course_id from the enrolment list.
 * Returns  0 on success.
 * Returns -1 if the student is not enrolled in the course.
 */
int student_drop_course(Student *s, int course_id);

/*
 * student_is_enrolled — checks membership in the enrolment list.
 * Returns 1 if enrolled, 0 otherwise.
 */
int student_is_enrolled(const Student *s, int course_id);

/* ---- Display ---- */

/* student_print — prints a formatted summary to stdout. */
void student_print(const Student *s);

#endif /* STUDENT_H */
